
# This file is responsible for controlling the way that a user interacts with an MVC application


import logging
import os
from google.cloud import storage
from flask import *
import urllib.request
from werkzeug.utils import secure_filename
from constants import fm_constants
from services.responseInfo import send_response
UPLOAD_FOLDER = fm_constants.UPLOAD
ALLOWED_EXTENSIONS = {'txt', 'pdf','xls','xlsx','csv'}


global filename
app = Flask(__name__)
app.secret_key = "secret key"


@app.route('/home',methods=['GET','POST'])
def upload():
    return render_template("index.html")


# Route for handling the login page logic
@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        if request.form['username'] != 'admin' or request.form['password'] != 'admin':
            error = 'Invalid Credentials. Please try again.'
        else:
            return redirect(url_for('upload'))
    return render_template('login.html', error=error)

@app.route('/uploadFile', methods=['POST'])
def upload_file():
	if request.method == 'POST':
        # check if the post request has the file part
		if 'file' not in request.files:
			flash('No file part')
			return redirect(url_for('upload'))
		file = request.files['file']
		if file.filename == '':
			flash('No file selected for uploading')
			return redirect(url_for('upload'))
		if file and allowed_file(file.filename):
			filename = secure_filename(file.filename)
			file.save(os.path.join(UPLOAD_FOLDER, filename))
			flash('File successfully uploaded')
			return redirect(url_for('upload'))
		else:
			flash('Allowed file types are txt and pdf')
			return redirect(url_for('upload'))

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/getAllFiles',methods=['GET'])
def get_files():
    file_names = os.listdir('./uploadedFile')
    print(file_names)
    return render_template("displayFiles.html", file_names=file_names)

@app.route('/getAllFiles/<filename>')
def return_files_tut(filename):
    #file_path = UPLOAD_FOLDER + filename
	return send_from_directory(UPLOAD_FOLDER, filename,as_attachment=True)
    #return send_file(file_path, as_attachment=True)


