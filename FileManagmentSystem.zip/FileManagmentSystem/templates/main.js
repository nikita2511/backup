
   
function uploadForm() {
  var x = document.getElementById("file-upload-form");
  var v=true;
  if (x.style.display === "none") {
    x.style.display = "block";
   
  } else {
    x.style.display = "none";
  
  }
}


function openNav(){
  document.getElementById("mySidenav").style.width = "250px";
  /* alert("helo"); */
}

function closeNav(){
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("model1").style.display="none";

}

function openModel(){
    document.getElementById("model1").style.display = "block";
}
