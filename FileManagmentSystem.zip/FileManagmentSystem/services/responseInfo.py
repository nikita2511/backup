from flask import render_template
import json

def send_response():
    val = json.loads(val)

    return render_template("error_response.html", status=404, msg="Uploaded Document is not in proper format,please check")