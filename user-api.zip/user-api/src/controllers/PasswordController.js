module.exports={
    register: async (req,res,next)=>{
        console.log("user password controller called")
        const userPassword = req.body
        console.log(userPassword);
    }
}