const { createUser, findByUserName, findAllUsers, findUserById, deleteUser, updateUser } = require("../services/UserService")
const bodyParser = require("body-parser");
module.exports = {

    //this method will call service method to create a user
    register: async(req, res, next) => {
        try {
            const user = req.body
            console.log("usercontroller is called")
            console.log(user);
            const result = await createUser(user)
            res.status(200).json({
                success: 1,
                message: "user has been added successfully"
            })

        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    },


    login: async(req, res, next) => {
        try {
            const user = req.body
            const result = await findByUserName(user)
            res.status(200).json({
                success: 1,
                message: `welcome ${result.name}`,
                data: result
            })
        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    },

    getAllUsers: async(req, res, next) => {
        try {
            const result = await findAllUsers()
            res.status(200).json({
                success: 1,
                data: result
            })
        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    },

    getUserById: async(req, res, next) => {
        try {
            const id = req.params.id
            const result = await findUserById(id)
            res.status(200).json({
                success: 1,
                data: result
            })
        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    },

    updateUser: async(req, res, next) => {
        try {
            const user = req.body
            const result = await updateUser(user)
            res.status(200).json({
                success: 1,
                data: result,
                message:"user has been updated successfully"
            })
        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    },

    deleteUser: async(req, res, next) => {
        try {
            const id = req.params.id
            const result = await deleteUser(id)
            res.status(200).json({
                success: 1,
                message: `record by id ${id} is deleted succesfully`
            })
        } catch (next) {
            res.status(201).json({
                success: 0,
                message: `${next.message}`
            })
        }

    }

}