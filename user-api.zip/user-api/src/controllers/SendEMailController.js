const {createEmail} = require("../services/SendEmailService")
const bodyParser = require("body-parser");
module.exports={
sendEmail:async(req,res,next)=>{
try{
const body=req.body
const contactNumber=body.contactNumber
console.log("---------------email controller called--------------------")
const result = await createEmail(contactNumber)
res.json({
    data:result
})
}
catch(next){
    res.json({
        message:next
    })
}
}
}