const nodeMailer = require("nodemailer")
// const sgMail = require('@sendgrid/mail');
module.exports={
    createEmail:(contactNumber)=>{
return new Promise((resolve,reject)=>{
// console.log("---------------email service called--------------------")
// sgMail.setApiKey("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");
// const msg = {
//   to: 'jaiswalchetan2306@gmail.com',
//   from: 'jaiswalnikita2911@gmail.com',
//   subject: 'just for fun!!!!!!!!!!!!!!',
//   text: 'oo dokri thi ni ghr ka samna woo pagal hui gyi bhai dekhna chalanaga apna wok heni',
//   html: '<strong>and easy to do anywhere, even with Node.js</strong>',
// }; 
// sgMail.send(msg).then((result)=>{
//   console.log(result)
// }).catch((error)=>{console.log(error)})

  let transport = nodeMailer.createTransport({
    host: 'smtp.mailtrap.io',
    port: 2525,
    auth: {
       user: 'b6e1a0a85a2c75',
       pass: 'a377621ac9261f'
    }
  });

  const message = {
    from: 'jaiswalnikita2911@gmail.com', // Sender address
    to: 'barkha1025@gmail.com',         // List of recipients
    subject: 'just for fun!!!!!!!!!!', // Subject line
    text: 'oo dokri thi ni ghr ka samna woo pagal hui gyi bhai dekhna chalanaga apna wok heni' // Plain text body
};
transport.sendMail(message, function(err, info) {
  if (err) {
    console.log(err)
   return reject(err)
  } else {
    console.log(info)
    return resolve(info)
  }
});
})

}
}