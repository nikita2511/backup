const db = require("../models/index")
const User = db.users
const UserPassword = db.UserPassword

module.exports= {
    createUser :(data)=>{
return new Promise( (resolve,reject)=>{
     db.sequelize.sync()
     Pass
})
    }
}