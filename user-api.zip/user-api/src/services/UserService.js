const db = require("../models/index")
const User = db.users
const UserPassword=db.passwords


module.exports = {
    createUser: (data) => {
        return new Promise((resolve, reject) => {
            db.sequelize.sync()
            User.findOne({
                where: { userName: data.userName }
            }).then((result) => {
                if (result == null) {
                    User.create(data).then((result) => {
                            UserPassword.create({
                                password:data.password,
                                userId:data.id
                            })  
                        return resolve(result)
                    }).catch((err) => {
                        console.log(err)
                        return reject(err)
                    })  
                } else {
                    return reject({ message: "userName already exist" })
                }

            }).catch((err) => {
                console.log(err)
                return reject(err)
            })
        })
    },

    findByUserName: (data) => {
        return new Promise((resolve, reject) => {
            User.findOne({
                where: { userName: data.userName }
            }).then((result) => {
                const user=result
                if (result != null) {
                    UserPassword.findOne({
                        where:{password:data.password},
                        where:{userId:user.id}
                    }).then((result) => {
                        if (result.password == data.password) {
                            return resolve(user)
                        } 
                        else
                        {
                            return reject({ message: "invalid password" })
                        }
                    });  
                }
                else{
                    return reject({ message: "invalid user please register yourself first" })
                }
               
            }).catch((err) => {
                return reject(err)

            });

        })


    },


    findAllUsers: () => {
        return new Promise((resolve, reject) => {
            User.findAll(
                {include:UserPassword}
            ).then((result) => {
                if (result == null) {
                    return reject({ message: "record not found" })
                }
                return resolve(result)
            }).catch((err) => {
                return reject(err)
            });

        })
    },


    findUserById: (id) => {
        return new Promise((resolve, reject) => {
            User.findOne({
                where: {
                    id: id
                }
            }).then((result) => {
                if (result == null) {
                    return reject({ message: "record not found" })
                }
                return resolve(result)
            }).catch((err) => {
                return reject(err)
            });

        })

    },

    updateUser: (data) => {
        return new Promise((resolve, reject) => {
            User.update(
                {name:data.name,email:data.email,password:data.password,contact:data.password},
                {where: {id: data.id} }
            ).then((result) => {
                 {
                     console.log(result)
                    return resolve({ message: result })
                }
               
            }).catch((err) => {
                console.log(err)
                return reject(err)
            });

        })

    },

    deleteUser: (id) => {
        return new Promise((resolve, reject) => {
            User.destroy({
                where: {
                    id: id
                }
            }).then((result) => {
                if (result == 1) {
                    return resolve({ message: `record whose id is ${id} deleted successfully` })
                }
                return reject({ message: `no record found by id : ${id} ` })
            }).catch((err) => {
                return reject(err)
            });

        })

    },






}