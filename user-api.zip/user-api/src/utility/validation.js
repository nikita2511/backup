const { check, validationResult } = require("express-validator");
//this method will validate registration body
exports.validateRegistration = [

    check('name').notEmpty().withMessage("please enter name of the user"),
    check('email').notEmpty().withMessage('please enter  email'),
    check('userName').isLength({ min: 5 }).withMessage("userName should be of length minimum 5 "),
    check('userName').isLength({ max: 10 }).withMessage("userName should be of length maximum 10 "),
    // check("password").matches(/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/, "i").withMessage("password should contain atleast one uppercase ,one lowercase and minmum length is 5 and maximum 20"),
    check('contact').isNumeric().withMessage("please enter digits only"),
    check('contact').isLength({ max: 10 }).withMessage("contact number should be maximum of length 10"),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(422).json({ errors: errors.array() });
        } else next();
    }
];


//this method will validate login body
exports.validateLogin = [

    check('userName', "please enter userName").notEmpty(),
    check('password', "please enter password").notEmpty(),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(422).json({ errors: errors.array() });
        } else next();
    }
];