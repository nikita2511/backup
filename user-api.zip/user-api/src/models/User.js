module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("users", {
        id:{
           type:Sequelize.STRING,
           primaryKey: true
        },
        name: {
            type: Sequelize.STRING
        },
        userName: {
            type: Sequelize.STRING
        },
        email: {
            type: Sequelize.STRING
        },
        contact: {
            type: Sequelize.STRING
        },
    })
    return User;
}