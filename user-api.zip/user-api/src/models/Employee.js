const { Model, json, DataTypes, Sequelize } = require("sequelize/types");

class Employee extends Model {

    static classLevelMethod() {
        return "classLevelMethod"
    }
    instanceLevelMethod() {
        return "instanceLevelMethod"
    }
    getFullName() {
        return [this.firstName, this.lastName].json()
    }
}

Employee.init({
    id: Sequelize.INTEGER,
    autoIncrement: true,
    unique: true,
    primaryKey: true
}, {
    firstName: Sequelize.TEXT,

}, {
    lastName: Sequelize.TEXT
}, {
    sequelize
})
const employee = Employee.build();