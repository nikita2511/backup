const dbConfig = require("../../config/database")
const Sequelize = require("sequelize");

const sequelize = new Sequelize('user_api', 'root', 'root', {
    host: 'localhost',
    dialect: 'mysql',
    operatorAliases: false, //for avoiding depricate warning
    pool: {
        max: dbConfig.pool.max,
        min: dbConfig.pool.min,
        acquire: dbConfig.pool.acquire, //for lock
        idle: dbConfig.pool.idle //connection time
    }
})
const db = {};
db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.users = require("./User")(sequelize, Sequelize)
db.passwords = require("./UserPassword")(sequelize, Sequelize)

db.users.hasOne(db.passwords)
db.passwords.belongsTo(db.users,{foreignKey: 'userId', constraints: false,allowNull: false})



//authentication
authenticate()

function authenticate() {
    try {
        sequelize.authenticate();
        console.log("connection has been established successfully")
    } catch (err) {
        console.log("connection failed")

    }
}

module.exports = db