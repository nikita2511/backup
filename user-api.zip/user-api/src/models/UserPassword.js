module.exports = (sequelize, Sequelize) => {
    const UserPassword = sequelize.define("passwords", {
        id:{
            type:Sequelize.INTEGER,
            autoIncrement: true,
            primaryKey: true
        },
        password:{
            type:Sequelize.STRING,
        },
       
    })
    return UserPassword;
}