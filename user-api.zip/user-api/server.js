const express = require("express")
const bodyParser = require("body-parser")
const userRouter = require("./src/router")
const app = express()
var cors = require('cors');
app.use(cors())

app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use("/", userRouter)

// app.get("/", console.log("server is starting"))


app.listen(3005, () => {
    console.log("server is running on port : 3005")
})