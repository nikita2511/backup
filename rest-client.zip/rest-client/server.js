//imports
const express = require("express")
const app = express()
const router = require("./src/router");
const bodyParser = require("body-parser")

//middlewares
app.use(express.json())
app.use(express.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use("/", router)


app.listen(5000, () => {
    console.log("server is running on port 5000")
})



















// const express = require("express")
// const app = express()
// var Client = require('node-rest-client').Client;
// var client = new Client();
// // var args = {
// //     data: { test: "hello" }, // data passed to REST method (only useful in POST, PUT or PATCH methods)
// //     // path: { "city": "indore" }, // path substitution var
// //     parameters: { arg1: "hello", arg2: "world" }, // this is serialized as URL parameters
// //     headers: { "test-header": "client-api" }, // request headers
// // };
// client.get("http://api.openweathermap.org/data/2.5/weather?q=indore&appid=b4f384e985d74fcdfaf708a54f0a0dd7&units=metric",args, function(data, response) {
//     // parsed response body as js object
//     console.log(data);
//     console.log(response);
// });
// client.registerMethod("jsonMethod", url, "GET");
// client.methods.jsonMethod(function(data, response) {
//     // parsed response body as js object
//     console.log(data);
//     // raw response
//     // console.log(response);
// });