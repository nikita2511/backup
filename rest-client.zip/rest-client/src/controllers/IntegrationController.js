const { integrationGetMethodService, integrationPostMethodService } = require("../services/IntegrationService")
const bodyParser = require("body-parser")



module.exports = {
    integrationMethod: async(req, res, next) => {
        try {
            const body = req.body
            const method = body.Headers[1].value
            if (method == 'GET') {
                const result = await integrationGetMethodService(body)
                res.json({
                    response: result.headers,
                    status: result.status,
                    statusText: result.statusText,
                    data: result.data
                })

            } else if (method == 'POST') {
                const result = await integrationPostMethodService(body)
                res.json({
                    response: result.headers,
                    status: result.status,
                    statusText: result.statusText,
                    data: result.data
                })
            }
        } catch (next) {
            res.json({
                status: `${next.response.status}`,
                statusText: `${next.response.statusText}`,

            })
        }
    },

}