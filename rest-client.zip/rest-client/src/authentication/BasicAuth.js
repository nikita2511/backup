const { hashSync, genSaltSync } = require("bcrypt")

//this method will generate token on the basis of given 
module.exports = {
    generateToken: (clientId, clientSecret) => {
        const salt = genSaltSync(10);
        token = hashSync(clientId + clientSecret, salt);
        return token;
    }


}