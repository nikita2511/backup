//this is a model which will set post body 
function Body(data) {
    this.body = data.Body.raw
}

Body.prototype.getBody = function() {
    return this.body;
}
module.exports = Body