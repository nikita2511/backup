function Url(data) {
    this.url = data.URL
}

Url.prototype.getUrl = function() {
    return this.url;
}
module.exports = Url