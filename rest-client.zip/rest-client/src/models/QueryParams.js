//this model will set Query parameters for get api call
function QueryParams(data) {
    var queryParams = data.QueryParams.map(function(param) {
        return param
    });
    var params = new URLSearchParams();
    for (let index = 0; index < queryParams.length; index++) {
        params.append(queryParams[index].key, queryParams[index].value)
    }
    this.params = params
}
QueryParams.prototype.getQueryParams = function() {
    return this.params;
}
module.exports = QueryParams