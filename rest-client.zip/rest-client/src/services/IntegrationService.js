const axios = require("axios")
const { setBasicAuthConfig, setOAuth2Config, setNoAuthConfig, setPostConfig, setConfigParams } = require("../utilities/configBody")



module.exports = {
    integrationGetMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            authType = body.Authorization.AuthType
            if (authType == 'BasicAuth') {
                const config = setBasicAuthConfig(body)
                clientId = body.Authorization.BasicAuth[0].value
                clientSecret = body.Authorization.BasicAuth[1].value
                axios(config).then((res) => {
                    console.log(res.data)
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            } else if (authType == 'OAuth2') {
                const config = setOAuth2Config(body)
                axios(config).then((res) => {
                    console.log(res)
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            } else {
                const config = setNoAuthConfig(body)
                axios(config).then((res) => {
                    console.log(res)
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            }
            if (body.QueryParams.key != "") {
                const config = setConfigParams(body)
                axios(config).then((res) => {
                    console.log(res)
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })

            }

        })
    },

    integrationPostMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            authType = body.Authorization.AuthType
            if (authType == 'BasicAuth') {
                const config = setPostConfig(body)
                axios(config).then((res) => {
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            } else if (authType == 'OAuth2') {
                const config = setPostConfig(body)
                axios(config).then((res) => {
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            } else {
                const config = setPostConfig(body)
                axios(config).then((res) => {
                    return resolve(res)
                }).catch((error) => {
                    return reject(error)
                })
            }

        })

    }

}