const axios = require("axios")

module.exports = {
    getAllJson: async(url, contentType, token) => {
        const result = await axios.get(url, {
            headers: {
                "Content-type": `${contentType}`,
                'Authorization': `${token}`,
            }
        })
        return result.data



    }



}