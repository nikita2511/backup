const { generateToken } = require("../authentication/BasicAuth")
const QueryParams = require("../models/QueryParams")
const Body = require("../models/Body")
const Url = require("../models/Url")
const MethodType = require("../models/MethodType")


module.exports = {

    //this method will set get method configuration for basic authentication 
    setBasicAuthConfig: (data) => {
        const URL = new Url(data)
        const methodType = new MethodType(data)
        const token = generateToken(data.Authorization.BasicAuth[0].value, data.Authorization.BasicAuth[1].value)
        const config = {
            url: URL.url,
            method: methodType.methodType,
            headers: { 'Content-Type': `${data.Headers[0].value}`, Authorization: `${token}` }
        }
        return config;
    },


    //this method will set get method  configuration for OAuth2 authentication 
    setOAuth2Config: (data) => {
        const URL = new Url(data)
        const methodType = new MethodType(data)
        const config = {
            url: URL.url,
            method: methodType.methodType,
            headers: {
                'Content-Type': `${data.Headers[0].value}`,
                Authorization: `Bearer ${data.Authorization.OAuth2[0].value}`
            }
        }
        return config;
    },


    //this method will set  get method configuration for No authentication
    setNoAuthConfig: (data) => {
        const URL = new Url(data)
        const methodType = new MethodType(data)
        const config = {
            url: URL.url,
            method: methodType.methodType,
            headers: { 'Content-Type': `${data.Headers[0].value}` }
        }
        return config;
    },


    //this method will set get method configuration for query parameters if user pass
    setConfigParams: (data) => {
        const URL = new Url(data)
        const methodType = new MethodType(data)
        const queryParams = new QueryParams(data)
        const config = {
            url: URL.url,
            method: methodType.methodType,
            headers: {
                'Content-Type': `${data.Headers[0].value}`,
            },
            params: queryParams.params

        }
        return config;
    },


    //this method will set configuration for Post method 
    setPostConfig: (data) => {
        const URL = new Url(data)
        const methodType = new MethodType(data)
        const body = new Body(data)
        const token = generateToken(data.Authorization.BasicAuth[0].value, data.Authorization.BasicAuth[1].value)
        const config = {
            url: URL.url,
            method: methodType.methodType,
            headers: {
                'Content-Type': `${data.Headers[0].value}`,
                'Authorization': `${token}`,
            },
            data: body.body
        }
        return config;
    }




}