const { check, validationResult, body } = require("express-validator");

//this method will validate registration body
exports.validateBody = [
    // check('body').isJSON().withMessage("please enter valid json"),
    check('URL').notEmpty().withMessage("URL cannot be blank"),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(422).json({ errors: errors.array() });
        } else next();
    }
];