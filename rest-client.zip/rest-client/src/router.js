const express = require("express")
const router = express.Router()
const { integrationMethod } = require("./controllers/IntegrationController");
const { validateBody } = require("./utilities/validation");

router.post("/request", validateBody, integrationMethod);
// router.post("/postRequest", integrationPostMethod);

module.exports = router