const { createPool } = require("mysql");
const pool = createPool({
    // user: process.env.DB_USER,
    // password: process.env.DB_PASS,
    // host: process.env.DB_HOST,
    // database: process.env.MYSQL_DB,
    // insecureAuth: true

    user: "root",
    password: "root",
    host: "localhost",
    database: "auth_demo"


})
module.exports = pool;