const { data, validationResult } = require('express-validator');
const User = function(body) {
    this.data = data
    this.errors = []
}
module.exports = User;