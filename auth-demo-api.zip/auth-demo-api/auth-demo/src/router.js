//custom module imports
const validate = require("./utility/validation");
const { register, login } = require("./controllers/userController");
const { registerUser } = require("./services/userService");
const router = require("express").Router();
const bodyParser = require("body-parser");


//routing
router.post("/register", validate.register, register);
router.post("/login", login)

//module exported so that another module can import this
module.exports = router