//module imports
const pool = require("../../config/database");
const bodyParser = require("body-parser");
const { genSaltSync, hashSync, compareSync } = require("bcrypt");
const { handleError } = require("../helper/error")


module.exports = {
    createUser: (data) => {
        return new Promise((resolve, reject) => {
            pool.query(
                `insert into registration(name,userName,email,password,contact)values(?,?,?,?,?)`, [
                    data.name,
                    data.userName,
                    data.email,
                    data.password,
                    data.contact
                ],

                (error, results, fields) => {
                    if (error) {
                        return reject(error)
                    }
                    return resolve(results)
                }

            )


        })
    },



    checkUser: (data) => {
        return new Promise((resolve, reject) => {
            // const salt = genSaltSync(10);
            // data.password = hashSync(data.password, salt);
            pool.query(
                `select * from registration where userName=?`, [
                    data.userName,
                ],
                (error, results, fields) => {
                    if (error) {
                        return reject(error)
                    }
                    return resolve(results)
                }

            )
        })

    },


    // findUserByUserName: (data) => {
    //     return new Promise((resolve, reject) => {
    //         pool.query(
    //             `select * from registration where userName=?`, [
    //                 data
    //             ],
    //             (error, results, fields) => {
    //                 if (error) {
    //                     console.log(error);
    //                     return reject(error)
    //                 }
    //                 return resolve(results[0])
    //             }

    //         )
    //     })

    // },




}