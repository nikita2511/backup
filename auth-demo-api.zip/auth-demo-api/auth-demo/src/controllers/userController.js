//module imports
const bodyParser = require("body-parser");
const { createUser, checkUser } = require("../services/userService");


module.exports = {

    //user registration controller method
    register: async(req, res, next) => {
        const body = req.body
        try {
            const result = await createUser(body)
            res.render("login")
                // req.flash('success', 'Employee added successfully');
            res.status(200).json({
                success: 1,
                message: "user has been registered successfully",
                data: result
            })
        } catch (e) {
            console.log(e);
            if (e.errno == 1062) {
                // res.status(201).json({
                //     success: 0,
                //     message: `userName ${body.userName} already exist`,

                // })

                res.render("registration", {
                    message: "userName already exist"
                })

            }


        }
    },


    //user login controller method
    login: async(req, res, next) => {
        try {
            const body = req.body
            const result = await checkUser(body)
            if (result[0] == null) {
                res.render("login", {
                        inValidUserMessage: "invalid user please  register yourself first"
                    })
                    // throw new Error("invalid user please  register yourself first");
            } else if (result[0].password != body.password) {
                res.render("login", {
                        passwordMessage: "invalid password"
                    })
                    // throw new Error("invalid password");
            } else {
                res.render("home", {
                    data: result[0],

                });
                // res.status(200).json({
                //     success: 1,
                //     message: `welcome ${result[0].name}`,
                //     data: result

                // })


            }
        } catch (next) {
            res.status(201).json({
                    success: 0,
                    message: next.message,

                }

            )

        }

    },


    // getUserByUserName: async(req, res) => {
    //     try {
    //         const body = req.body
    //         var result = await findUserByUserName(body.userName)
    //         console.log(result)
    //         return res.json({
    //             success: 1,
    //             data: result
    //         });

    //     } catch (e) {
    //         return res.json({
    //             success: 0,
    //             data: "there is error "
    //         });
    //         // res.render("register")

    //     }

    // },



}