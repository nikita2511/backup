// module imports
const express = require("express");
require("dotenv").config();
const { errorHandler } = require("error-express-handler");
const userRouter = require("./src/router");
const app = express();


//middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use("/", userRouter)
app.use(errorHandler);
app.set("views", "./views");
app.set("view engine", "hbs")

//login html rendering
app.get("/login", (req, res) => {
    res.render("login");
})

//registration html rendering
app.get("/registration", (req, res) => {
    res.render("registration");
})

//port on which application will run
app.listen(process.env.APP_PORT, () => {
    console.log("listening to port no. : " + process.env.APP_PORT);
});