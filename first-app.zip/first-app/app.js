//load module
var http = require("http");

//create server

http
  .createServer(function (request, response) {
    response.writeHead(200, { "content-Type": "text/plain" });
    response.end("hello world\n");
  })
  .listen(3001);
console.log("Server running at http://127.0.0.1:3001/");
