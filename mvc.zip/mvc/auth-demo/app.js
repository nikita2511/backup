const express = require("express");
const userRouter = require("./src/router");
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use("/", userRouter)
app.set("views", "./views");
app.set("view engine", "hbs")
require("dotenv").config();
app.get("/login", (req, res) => {
    res.render("login");
})
app.get("/registration", (req, res) => {
    res.render("registration");
})

app.listen(process.env.APP_PORT, () => {
    console.log("listening to port no. : " + process.env.APP_PORT);
});