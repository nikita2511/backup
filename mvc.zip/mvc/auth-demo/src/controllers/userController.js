const bodyParser = require("body-parser");
const { registerUser, loginUser } = require("../services/userService");
const { registrationValidation } = require("../utility/validation");
module.exports = {

    register: (req, res) => {

        console.log("register called");
        const body = req.body
        console.log(body)

        registrationValidation(body, (result) => {

        })
        registerUser(body, (error, result) => {
            if (error) {

                // return res.status(500).json({
                //     sucess: 0,
                //     message: "database connection error"
                // });
                // res.send({ errorMsg: "data updated successfully ", redirect_path: "../../views/login.hbs" });
                res.send("error");


            } else {
                // return res.status(200).json({
                //     sucess: 1,
                //     data: result
                // })
                res.render("login");



            }

        })

    },

    login: (req, res) => {

        console.log("login controller called");
        const body = req.body
        console.log(body)
        loginUser(body, (error, result) => {
            if (error) {
                return res.status(500).json({
                    sucess: 0,
                    message: "database connection error"
                });
            } else if (result == "invalid password") {
                res.render("login", { invalidPasswordMessage: "invalid password" })
            } else if (result == "invalid user please register yourself") {
                res.render("login", { invalidUserMessage: "iinvalid user please register yourself" })
            } else {
                res.render("home", {
                    data: JSON.stringify(result)
                });
            }

        })

    },



}