const pool = require("../../config/database");

module.exports = {

    createUser: (data, callBack) => {
        console.log("dao called");
        console.log(data);
        pool.query(
            `insert into registration(name,userName,email,password,contact)values(?,?,?,?,?)`, [
                data.name,
                data.userName,
                data.email,
                data.password,
                data.contact
            ],

            (error, results, fields) => {
                if (error) {
                    console.log(error);
                    return callBack(error)
                }
                return callBack(null, results)
            }

        )
    },

    checkUser: (data, callBack) => {
        console.log(" login dao called");
        console.log(data);
        pool.query(
            `select * from registration where userName=?`, [
                data.userName,
            ],

            (error, results, fields) => {
                console.log(JSON.stringify(results).length)
                if (error) {
                    console.log(error);
                    return callBack(error)
                }
                return callBack(null, results[0])
            }

        )
    }


}