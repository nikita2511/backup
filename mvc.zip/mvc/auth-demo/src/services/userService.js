const { createUser, checkUser } = require("../dao/userDao");
module.exports = {

    registerUser: (data, callBack) => {
        console.log("registerUser called")
        console.log(data)
        createUser(data, callBack)
    },


    loginUser: (data, callBack) => {
        checkUser(data, (err, result) => {
            if (err) {
                return callBack(err)
            } else if (result) {
                if (result.password == data.password) {
                    return callBack(null, result)
                } else {
                    return callBack(null, "invalid password")
                }
            } else {
                return callBack(null, "invalid user please register yourself")
            }
        })
    }



}