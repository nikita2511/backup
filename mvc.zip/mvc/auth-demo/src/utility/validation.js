const { check, validationResult } = require("express-validator");
module.exports = {

    registrationValidation: (data, callback) => {
        if (data.name == "") {
            return callback(false)
        } else {
            callback(false)
        }
    }


}