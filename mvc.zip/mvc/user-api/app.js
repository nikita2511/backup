const express = require("express");
require("dotenv").config();
const app = express();
app.use(express.json());
const userRouter = require("./api/users/users.router");
app.use("/api/users", userRouter);
app.listen(process.env.APP_PORT, () => {
    console.log("my app is running" + process.env.APP_PORT);
});