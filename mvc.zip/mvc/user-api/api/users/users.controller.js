const bodyParser = require("body-parser");
const { create, getUserByUserId, deleteUser, getUsers, updateUser, getUserByUserEmail } = require("./users.service");
const { genSaltSync, hashSync, compareSync } = require("bcrypt");
const { sign } = require("jsonwebtoken");

module.exports = {
    createUser: (req, res) => {
        console.log("controller called");
        const body = req.body
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        create(body, (error, results) => {
            if (error) {
                console.log(error);
                return res.status(500).json({
                    sucess: 0,
                    message: "databse connection error"
                });
            }
            return res.status(200).json({
                sucess: 1,
                data: results
            });


        })
    },

    getUserByUserId: (req, res) => {
        const id = req.params.id;
        console.log("getUserById controller called")
        console.log(id)
        getUserByUserId(id, (err, results) => {
            if (err) {
                console.log(err);
                return;
            }

            if (!results) {
                return res.json({
                    success: 0,
                    message: "record not found"
                })

            }
            return res.json({
                success: 1,
                data: results
            });
        });

    },

    getUsers: (req, res) => {
        console.log(" getusers controller called")
        getUsers((error, results) => {
            if (error) {
                console.log(error);
                return;

            }
            if (!results) {
                return res.json({
                    success: 0,
                    message: "record not found"
                })

            }
            return res.json({
                sucess: 1,
                data: results
            });
        })
    },

    updateUser: (req, res) => {
        console.log("controller called");
        const body = req.body
        const salt = genSaltSync(10);
        body.password = hashSync(body.password, salt);
        updateUser(body, (error, results) => {
            if (error) {
                console.log(error);
                return;

            }
            return res.json({
                sucess: 1,
                message: "user updated successfully"

            });


        })
    },

    deleteUser: (req, res) => {
        console.log(" delete controller called");
        const id = req.params.id;
        console.log(id);
        deleteUser(id, (error, results) => {
            if (error) {
                console.log(error);
                return;
            }

            return res.json({
                success: 1,
                message: " user deleted succesfully",
                data: results
            });
        });

    },
    login: (req, res) => {
        const body = req.body;
        getUserByUserEmail(body.email, (error, results) => {
            if (error) {
                console.log(error)
            }
            if (!results) {
                res.json({
                    success: 0,
                    data: "invalid user or password"
                })
            }
            const result = compareSync(body.password, results.password);
            if (result) {
                results.password = undefined
                const jsonToken = sign({ result: results }, "niki123", {
                    expiresIn: "1h"
                });
                return res.json({
                    success: 1,
                    token: jsonToken
                });
            } else {
                res.json({
                    success: 0,
                    data: "invalid user or password"
                })
            }
        })

    }


}