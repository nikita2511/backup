const pool = require("../../config/database");
module.exports = {
    create: (data, callBack) => {
        console.log("service called");
        pool.query(
            `insert into registration(name,email,contact,password,gender)values(?,?,?,?,?)`, [
                data.name,
                data.email,
                data.contact,
                data.password,
                data.gender
            ],
            (error, results, fields) => {

                if (error) {
                    console.log(error)
                    return callBack(error)
                }
                return callBack(null, results)
            }
        )

    },

    getUserByUserId: (id, callBack) => {

        console.log("get UserById service is called")
        pool.query(`select name,email,contact,password,gender from registration where id = ?`, [id],
            (err, results, fields) => {

                if (err) {
                    console.log(err)
                    return callBack(err)
                }
                return callBack(null, results[0])
            });
    },

    getUsers: callBack => {

        console.log("service called");
        pool.query(
            `select name,email,contact,password,gender from registration`, [],
            (error, results, fields) => {

                if (error) {
                    console.log(error)
                    return callBack(error)
                }
                return callBack(null, results)

            });
    },

    updateUser: (data, callBack) => {

        pool.query(`update registration set name=?,email=?,contact=?,password=?,gender=? where id=?`, [
                data.name,
                data.email,
                data.contact,
                data.password,
                data.gender,
                data.id

            ],
            (error, results, fields) => {

                if (error) {
                    console.log(error)
                    return callBack(error)
                }
                return callBack(null, results[0])
            })
    },

    deleteUser: (id, callBack) => {
        console.log("delete ervice called")
            //  console.log(data.id);
        pool.query(`delete from registration where id=?`, [id],
            (error, results, fields) => {

                if (error) {
                    console.log(error)
                    return callBack(error)
                }
                console.log(results)
                return callBack(null, results)
            })
    },

    getUserByUserEmail: (email, callBack) => {

        pool.query(
            `select * from registration where email=?`, [email],
            (error, results, fields) => {
                if (error) {
                    callBack(error)
                }

                return callBack(null, results[0])
            })
    }

}