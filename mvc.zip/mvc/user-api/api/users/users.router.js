const {createUser,getUserByUserId,getUsers,deleteUser,updateUser,login} = require("./users.controller");
const router = require("express").Router();
// let {checkToken} = require("../../auth/token_validation");

router.post("/",createUser)   
router.get("/all",getUsers)     
router.get("/:id",getUserByUserId)     
router.patch("/update",updateUser)   
router.delete("/delete/:id",deleteUser)     
router.post("/login",login)  
module.exports= router;   