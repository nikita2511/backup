const {createPool} = require("mysql");
const pool = createPool({

    user :process.env.DB_USER,
    password :process.env.DB_PASS,
    host:process.env.DB_HOST,
    database:process.env.MYSQL_DB,
    connectionLimit:10
    
})

module.exports=pool;
console.log("database called");