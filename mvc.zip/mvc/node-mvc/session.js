var express = require("express");
var app = express();
var cookieParser  = require("cookie-parser");
var session = require("express-session");
const { json } = require("express");
app.use(cookieParser())

app.use(session({secret : "abc123"}))

app.get("/set_session",(req,res)=>{
    if(req.session.count){
        req.session.count++
        res.send("count"+ req.session.count);
    }
    else{

        req.session.count=1;
        res.send("welcome first time count :"+ req.session.count);
    }
  
})
app.listen(3000)