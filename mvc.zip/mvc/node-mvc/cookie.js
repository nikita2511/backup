var express = require("express");
var app = express();
var cookieParser  = require("cookie-parser");
const { json } = require("express");
app.use(cookieParser())
app.get("/cookie_test",(req,res)=>{

    res.cookie("userName","nikitajaiswal");
    res.send("------------cookie set-------------");
})

app.get("/cookie_check",(req,res)=>{

    res.cookie("userName","nikitajaiswal",{maxAge:10000});
    res.send("cookie"+JSON.stringify(req.cookies));
})

app.get("/cookie_clear",(req,res)=>{

    res.clearCookie("userName");
    res.send("cookie"+JSON.stringify(req.cookies));
})
app.listen(3000)