let p = new Promise((resolve,reject)=>{
let a=1+2;
if(a==2){
    resolve("yess this is true")
}
else{
    reject("noo this is false")
}
})
p.then((message)=>{
    console.log("this is then :"+message)
}).catch((message)=>{
    console.log("this is then :"+message)

})