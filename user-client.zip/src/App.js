import logo from './logo.svg';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import Header from './components/layout/Header';
import { BrowserRouter as Router, Route } from "react-router-dom";
import Dashboard from './components/Dashboard';
import Register from './components/users/Register'
import Login from './components/users/Login';
import ListUsers from './components/users/ListUsers';
import UpdateUser from './components/users/UpdateUser';
import { Provider } from "react-redux";
import  store from "./store";
import Home from './components/users/Home';
import ChangePassword from './components/users/ChangePassword';
import ForgotPassword from './components/users/ForgotPassword';
import OtpVerification from './components/users/OtpVerification';
import UpdateProfile from './components/users/UpdateProfile';


function App() {
  return (
    <div className="App">
     {/* <Provider store={store}> */}
    <Router>
    <Header/>
      <Route  path="/dashboard" component={Dashboard}/>
      <Route  path="/register" component={Register}/>
      <Route  path="/login" component={Login}/>
      <Route  path="/listUsers" component={ListUsers}/>
      <Route  path="/updateUser/:id" component={UpdateUser}/>
      <Route  path="/home/:id" component={Home}/>
      <Route  path="/forgotPassword" component={ForgotPassword}  />
      <Route  path="/otpVerification" component={OtpVerification}  />
      <Route  path="/changePassword" component={ChangePassword}  />
      <Route  path="/updateProfile" component={UpdateProfile}  />


    </Router>
    {/* </Provider> */}
    </div>
  );
}

export default App;
