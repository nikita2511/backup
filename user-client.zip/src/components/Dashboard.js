import React, {Component} from 'react';

class Dashboard extends Component {
  render () {
    return (
      <div>
        <div class="card bg-light shadow-lg rounded">
          <div class="card-body">
            <h5 class="card-title text-danger pt-5 h3">USER MANAGEMENT TOOL</h5>
          </div>
        </div>
      </div>
    );
  }
}

export default Dashboard;
