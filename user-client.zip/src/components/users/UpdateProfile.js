import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';

class UpdateProfile extends Component {
  constructor (props) {
    super (props);
    this.state = {
      profile: '',
    };
    this.onChange = this.onChange.bind (this);
  }
  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }
  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        <span className="">select profile picture </span>
        <br />
        <br />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicOtp" className="mb-3">
                <FormControl
                  type="file"
                  name="profile"
                  placeholder="choose profile"
                  value={this.state.profile}
                  onChange={this.onChange}
                />
              </FormGroup>
              <Button
                variant="primary"
                className="expand"
                onClick={this.saveProfile}
              >
                upload
              </Button>
            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default UpdateProfile;
