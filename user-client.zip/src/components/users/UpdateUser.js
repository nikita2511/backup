// import { Alert } from 'bootstrap';
import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';
// import {createUser  } from "./../../actions/UserActions";
// import { connect } from "react-redux";
// import PropTypes from "prop-types";

class UpdateUser extends Component {
  constructor (props) {
    super (props);
    console.log (props);
    this.state = {
      id: '',
      name: '',
      userName: '',
      email: '',
      password: '',
      contact: '',
      alertMsg: '',
    };
    this.onChange = this.onChange.bind (this);
  }

  componentDidMount () {
    const {id} = this.props.match.params;
    this.getUser (id);
  }

  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }
  // add record
  getUser = id => {
    fetch ('http://localhost:3005/' + id, {
      method: 'GET',
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
        this.setState ({
          id: result.data.id,
          name: result.data.name,
          userName: result.data.userName,
          email: result.data.email,
          password: result.data.password,
          contact: result.data.contact,
        });
      })
      .catch (error => {
        console.log (error);
      });
  };

  updateUser = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({
      id: this.state.id,
      name: this.state.name,
      userName: this.state.userName,
      email: this.state.email,
      password: this.state.password,
      contact: this.state.contact,
    });

    fetch ('http://localhost:3005/updateUser', {
      method: 'PUT',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
        this.setState ({
          id: '',
          name: '',
          userName: '',
          email: '',
          password: '',
          contact: '',
          alertMsg: result.message,
        });
      });
  };

  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        {/* <i className="fa fa-user-plus p-3 mb-3 fa-3x"></i> */}
        <p className="text-success">{this.state.alertMsg}</p>
        <h2 className="pb-5">Update user</h2>
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicId" className="mb-3">
                <FormControl
                  type="number"
                  name="id"
                  placeholder="Enter name"
                  disabled
                  value={this.state.id}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicName" className="mb-3">
                <FormControl
                  type="text"
                  name="name"
                  placeholder="Enter name"
                  value={this.state.name}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicUsername" className="mb-3">
                <FormControl
                  type="text"
                  name="userName"
                  placeholder="Enter Username"
                  value={this.state.userName}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicEmail" className="mb-3">
                <FormControl
                  type="email"
                  name="email"
                  placeholder="Enter email"
                  value={this.state.email}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicPassword" className="mb-3">
                <FormControl
                  type="password"
                  name="password"
                  placeholder="Enter password"
                  value={this.state.password}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicContact" className="mb-3">
                <FormControl
                  type="text"
                  name="contact"
                  placeholder="Enter contact"
                  value={this.state.contact}
                  onChange={this.onChange}
                />
              </FormGroup>

              <Button variant="primary" onClick={this.updateUser}>
                Submit
              </Button>
            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default UpdateUser;
