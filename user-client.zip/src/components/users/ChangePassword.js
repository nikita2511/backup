import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';
import {Link} from 'react-router-dom';

class ChangePassword extends Component {
  constructor (props) {
    super (props);
    this.state = {
      userId: '',
      newPassword: '',
      confirmPassword: '',
    };
    this.onChange = this.onChange.bind (this);
  }
  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }
  changePassword = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({
      userId: this.state.userId,
      newPassword: this.state.newPassword,
      confirmPassword: this.state.confirmPassword,
    });
    fetch ('http://localhost:3005/changePassword', {
      method: 'POST',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
      })
      .catch (error => {
        console.log (error);
      });
  };

  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        <h2 className="">Change Password</h2>
        <br />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicId" className="mb-3">
                <FormControl
                  type="number"
                  name="userId"
                  placeholder="Enter user Id"
                  value={this.state.userId}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicPassword" className="mb-3">
                <FormControl
                  type="password"
                  name="newPassword"
                  placeholder="Enter new Password"
                  value={this.state.newPassword}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicPassword" className="mb-3">
                <FormControl
                  type="password"
                  name="confirmPassword"
                  placeholder="Enter password again"
                />
              </FormGroup>

              <Button
                variant="primary"
                className="expand"
                onClick={this.changePassword}
              >
                Save Password
              </Button>
              <div>
                {' '}<Link to="/login" className="text-primary h6">login</Link>
              </div>

            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default ChangePassword;
