import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';
import {Link} from 'react-router-dom';

class ForgotPassword extends Component {
  constructor (props) {
    super (props);
    this.state = {
      email: '',
    };
    this.onChange = this.onChange.bind (this);
  }
  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }

  sendOtp = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({email: this.state.email});
    fetch ('http://localhost:3005/forgotPassword', {
      method: 'POST',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
      })
      .catch (error => {
        console.log (error);
      });
  };

  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        <span className="">Enter your email address for verication code </span>
        <br />
        <br />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicEmail" className="mb-3">
                <FormControl
                  type="email"
                  name="email"
                  placeholder="Enter email for verification"
                  value={this.state.email}
                  onChange={this.onChange}
                />
              </FormGroup>
              <Link to="/otpVerification">
                <Button
                  variant="primary"
                  className="expand"
                  onClick={this.sendOtp}
                >
                  Send Verification Code{' '}
                </Button>
              </Link>
            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default ForgotPassword;
