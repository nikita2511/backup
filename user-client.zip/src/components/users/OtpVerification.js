import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';
import {Link} from 'react-router-dom';

class OtpVerification extends Component {
  constructor (props) {
    super (props);
    this.state = {
      otp: '',
    };
    this.onChange = this.onChange.bind (this);
  }
  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }

  verify = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({otp: this.state.otp});
    fetch ('http://localhost:3005/otpVerification', {
      method: 'POST',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
      })
      .catch (error => {
        console.log (error);
      });
  };

  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        <span className="">Please enter verication code </span>
        <br />
        <br />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicOtp" className="mb-3">
                <FormControl
                  type="text"
                  name="otp"
                  placeholder="Enter otp"
                  value={this.state.otp}
                  onChange={this.onChange}
                />
              </FormGroup>
              <Link to="/changePassword">
                <Button
                  variant="primary"
                  className="expand"
                  onClick={this.verify}
                >
                  Verify
                </Button>
              </Link>

            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default OtpVerification;
