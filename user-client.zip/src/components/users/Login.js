import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';
import Home from './Home';
import {Link} from 'react-router-dom';

class Login extends Component {
  constructor (props) {
    super (props);
    this.state = {
      userName: '',
      password: '',
      user: {},
    };
    this.onChange = this.onChange.bind (this);
  }
  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }
  // add record

  login = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({
      name: this.state.name,
      userName: this.state.userName,
      email: this.state.email,
      password: this.state.password,
      contact: this.state.contact,
    });
    fetch ('http://localhost:3005/login', {
      method: 'POST',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
        this.setState ({user: result.user});
      })
      .catch (error => {
        console.log (error);
      });
  };

  // }
  render () {
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        <i className="fa fa-user-plus p-3 mb-3 fa-3x" />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicUsername" className="mb-3">
                <FormControl
                  type="text"
                  name="userName"
                  placeholder="Enter Username"
                  value={this.state.userName}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicPassword" className="mb-3">
                <FormControl
                  type="password"
                  name="password"
                  placeholder="Enter password"
                  value={this.state.password}
                  onChange={this.onChange}
                />
              </FormGroup>

              <Button variant="primary" className="expand" onClick={this.login}>
                Login
              </Button>

              <div>

                <Link to="/forgotPassword" className="text-primary h6">
                  forgot password?
                </Link>
              </div>

            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Login;
