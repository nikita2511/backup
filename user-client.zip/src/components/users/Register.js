// import { Alert } from 'bootstrap';
import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
} from 'react-bootstrap';

class Register extends Component {
  constructor (props) {
    super (props);
    this.state = {
      id: '',
      name: '',
      userName: '',
      email: '',
      password: '',
      contact: '',
      showAlert: false,
      alertMsg: '',
      alertType: '',
      errors: [],
    };
    this.onChange = this.onChange.bind (this);
  }

  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }
  // add record
  addUser = () => {
    var myHeaders = new Headers ();
    myHeaders.append ('content-Type', 'application/json');
    var body = JSON.stringify ({
      id: this.state.id,
      name: this.state.name,
      userName: this.state.userName,
      email: this.state.email,
      password: this.state.password,
      contact: this.state.contact,
    });

    fetch ('http://localhost:3005/register', {
      method: 'POST',
      headers: myHeaders,
      body: body,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result.errors);
        this.setState ({
          id: '',
          name: '',
          userName: '',
          email: '',
          password: '',
          contact: '',
          showAlert: true,
          alertMsg: result.message,
          alertType: 'success',
          errors: result.errors,
        });
      })
      .catch (error => {
        console.log (error);
      });
  };

  // }
  render () {
    const {alertMsg, errors} = this.state;
    return (
      <div className="col-md-6 bg-light p-5 m-auto ">
        {this.state.alertType === 'success'
          ? <h2 className="text-success">{alertMsg}</h2>
          : errors.map (err => {
              return <p className="text-danger">{err}</p>;
            })}
        <i className="fa fa-user-plus p-3 mb-3 fa-3x" />
        <Container>
          <Row>
            <Form>
              <FormGroup controlId="formBasicId" className="mb-3">
                <FormControl
                  type="number"
                  name="id"
                  placeholder="Enter userId"
                  value={this.state.id}
                  onChange={this.onChange}
                />
              </FormGroup>
              <FormGroup controlId="formBasicName" className="mb-3">
                <FormControl
                  type="text"
                  name="name"
                  placeholder="Enter name"
                  value={this.state.name}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicUsername" className="mb-3">
                <FormControl
                  type="text"
                  name="userName"
                  placeholder="Enter Username"
                  value={this.state.userName}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicEmail" className="mb-3">
                <FormControl
                  type="email"
                  name="email"
                  placeholder="Enter email"
                  value={this.state.email}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicPassword" className="mb-3">
                <FormControl
                  type="password"
                  name="password"
                  placeholder="Enter password"
                  value={this.state.password}
                  onChange={this.onChange}
                />
              </FormGroup>

              <FormGroup controlId="formBasicContact" className="mb-3">
                <FormControl
                  type="text"
                  name="contact"
                  placeholder="Enter contact"
                  value={this.state.contact}
                  onChange={this.onChange}
                />
              </FormGroup>

              <Button variant="primary" onClick={this.addUser}>
                Submit
              </Button>
            </Form>
          </Row>
        </Container>
      </div>
    );
  }
}

export default Register;
