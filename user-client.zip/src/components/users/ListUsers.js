import React, {Component} from 'react';
import {
  Form,
  Button,
  Container,
  Row,
  FormControl,
  FormGroup,
  Alert,
  Table,
} from 'react-bootstrap';
import {Link} from 'react-router-dom';

class ListUsers extends Component {
  constructor (props) {
    super (props);
    this.state = {
      name: '',
      userName: '',
      email: '',
      password: '',
      contact: '',
      users: [],
    };
  }

  componentDidMount () {
    this.fetchAllRecords ();
  }

  onChange (event) {
    this.setState ({[event.target.name]: event.target.value});
  }

  // fetch all records
  fetchAllRecords = () => {
    var headers = new Headers ();
    headers.append ('content-Type', 'application/json');
    fetch ('http://localhost:3003/getAllUsers', {
      method: 'PATCH',
      headers: headers,
    })
      .then (response => response.json ())
      .then (result => {
        this.setState ({
          users: result.data,
        });
        console.log (result);
      })
      .catch (error => {
        console.log (error);
      });
  };

  // delete user
  deleteUser = id => {
    var headers = new Headers ();
    headers.append ('content-Type', 'application/json');
    fetch ('http://localhost:3005/' + id, {
      method: 'DELETE',
      headers: headers,
    })
      .then (response => response.json ())
      .then (result => {
        console.log (result);
      })
      .catch (error => {
        console.log (error);
      });
  };

  render () {
    return (
      <div className="col-md-10 d-flex p-5 m-auto ">
        <Container>
          <h1 className="text-warning">All USERS </h1>
          <Row>
            {/* <p>List of all users{this.users}</p> */}
            <Table
              striped
              bordered
              hover
              size="small"
              className="m-auto bg-light"
            >
              <thead>
                <tr>
                  <th>
                    Id
                  </th>
                  <th>Name</th>
                  <th>UserName</th>
                  <th>Email</th>
                  <th>password</th>
                  <th>contact</th>
                  <th colSpan="2">Actions</th>
                </tr>
              </thead>
              <tbody>
                {this.state.users.map (user => {
                  return (
                    <tr>
                      <td>{user.id}</td>
                      <td>{user.name}</td>
                      <td>{user.userName}</td>
                      <td>{user.email}</td>
                      <td>{user.password.password}</td>
                      <td>{user.contact}</td>
                      <td>
                        <Link to={`/updateUser/${user.id}`}>
                          <Button variant="info">
                            <i class="fa fa-pencil" aria-hidden="true" />Edit
                          </Button>
                        </Link>
                      </td>
                      <td>
                        <Button
                          variant="danger"
                          onClick={this.deleteUser (user.id)}
                        >
                          <i class="fa fa-trash-o" aria-hidden="true" />Delete
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </Table>
          </Row>
        </Container>
      </div>
    );
  }
}
export default ListUsers;
