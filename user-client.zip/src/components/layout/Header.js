import React, {Component} from 'react';
import {Link} from 'react-router-dom';

class Header extends Component {
  render () {
    return (
      <div className="mb-5">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <button
              class="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNav"
              aria-controls="navbarNav"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span class="navbar-toggler-icon" />
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav">
                <li class="nav-item">
                  <Link to="/dashboard" className="text-info h6">
                    Dashboard
                  </Link>
                </li>
              </ul>
            </div>
            <div className="float-right">
              <div
                className="collapse navbar-collapse float-right"
                id="navbarNav"
              >
                <ul class="navbar-nav">
                  <li className="nav-item">
                    <Link to="/register" className="text-info h6 btn">
                      Register <i className="fa fa-user-plus  fa-xs" />
                    </Link>
                  </li>
                  <li class="nav-item">
                    <Link to="/login" className="text-info h6 ml-4 btn">
                      Login <i class="fa fa-sign-in fa-xs" aria-hidden="true" />
                    </Link>
                  </li>
                  <li class="nav-item">
                    <Link to="/listUsers" className="text-info h6 ml-4 btn">
                      List
                    </Link>
                  </li>
                  <li class="nav-item">
                    <Link to="/updateProfile" className="text-info h6 ml-4 btn">
                      upload profile
                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>
      </div>
    );
  }
}

export default Header;
