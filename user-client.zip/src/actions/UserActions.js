// import axios from "axios";
// import {GET_USERS} from "./type"

// export const createUser=(user,history)=> async dispatch=>{
//     try{
//         const res = await axios.post("http://localhost:3003/register",user,{headers: {
//             'Content-Type': 'application/json;charset=UTF-8' 
//           }});
//         console.log(res)
//         history.push("/dashboard")
//     }
//     catch(error){
//         dispatch({
//             type:GET_USERS,
//             payload:error.res
//         })
//     }
// }