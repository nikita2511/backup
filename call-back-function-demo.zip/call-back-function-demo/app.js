//examle for blocking io

var fs = require("fs");
// var data = fs.readFileSync("input.txt");
// console.log(data.toString());
// console.log("program ended");

// example for non-blocking io
fs.readFile("input.txt", function (err, data) {
  if (err) console.log(err);
  console.log(data.toString());
});
console.log("program ended");
