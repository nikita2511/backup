const socket = io()
let name;

let textarea = document.querySelector('#text_area')
let messageArea = document.querySelector('.message_area')
do{
    userName = prompt('please enter username :')
}while(!userName){

}

textarea.addEventListener('keyup', (e)=>{
    if(e.key ==='Enter')
    {
        sendMessage(e.target.value)
    }
})

function sendMessage(message){
    let msg = {
        user:userName,
        message:message.trim()
    }

    appendMessage(msg,'outgoing')
    textarea.value=''
    scrollToBottom()

    //sendToServer
    socket.emit('message',msg)

}

function appendMessage(msg,type){ 
    let mainDiv = document.createElement('div')
    let className = type
    mainDiv.classList.add(className,'message')
    let markup = `
    <h4>${msg.user}</h4>
    <p>${msg.message}</p>
    `
    mainDiv.innerHTML = markup
    messageArea.appendChild(mainDiv)
 
}

//recievemessages

socket.on('message',(msg)=>{

    appendMessage(msg,'incoming')
    scrollToBottom()
})

function scrollToBottom(){
    messageArea.scrollTop= messageArea.scrollHeight
}