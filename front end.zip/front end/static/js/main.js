function validateForm(){
 
  var input =document.getElementById("myFile").value;
  if(input==="")
  {
    document.getElementById("errMsg").innerHTML="please choose file";
    return false;
  }
}

function databaseConnection()
{
  alert("{{message}}");
}


 
