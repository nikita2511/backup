var fs = require("fs");
var express = require("express");
var app = express();

var bodyParser = require("body-parser");
var multer = require("multer");
const { static } = require("express");
app.use(express.static("./public"));
