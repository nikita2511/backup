const { response } = require("express");
var express = require("express");
var app = express();
app.use(express.static("./public"));

app.get("/index.html", function (req, res) {
  res.sendFile(__dirname + "/" + "index.html");
});

// app.post("/", function (req, res) {
//   console.log("this is post api");
//   res.send("hello post");
// });

app.post("/process_get", function (req, res) {
  response = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
  };
  //   console.log(response);
  res.end(JSON.stringify(response));
});

// app.get("/ab*cd", function (req, res) {
//   console.log("this ispattern match api ");
//   res.send("page pattern match");
// });
// console.log(response);
var server = app.listen(3001, function () {
  var host = server.address().host;
  var port = server.address().port;

  console.log("example ilsteneing at  at http://%s:%s", host, port);
});
