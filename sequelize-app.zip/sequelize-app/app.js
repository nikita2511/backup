const express = require("express")
const bodyParser = require("body-parser")
const mysql = require("mysql")
const path = require("path")
const app = express();
const db = require("./config/database");
const userRouter = require("./src/route")
app.set('views', "./src/views")
app.set('view engine', 'hbs')
app.use("/", userRouter)
db.authenticate()
    .then(() =>
        console.log("databse connected successfully")
    )
    .catch((err) => console.log("database connection failed error : " + err))
    //test database connection

app.get("/", (req, res) => {
    res.send("hiii this is demo");
})
app.listen(3000, console.log("server started on port : 3000"))