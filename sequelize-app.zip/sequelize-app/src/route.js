const express = require("express")
const router = express.Router()
const db = require("../config/database")
const User = require("../src/models/User")

router.get('/', (req, res) => {
    db.sync()
    User.create()
        .then((users) => {
            console.log(users)
            res.sendStatus(200)
        }).catch((err) => {
            console.log(err)
        })
})

module.exports = router