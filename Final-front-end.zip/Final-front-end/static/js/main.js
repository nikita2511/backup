

//  This function will validate uplaod Form
function validateUploadForm() {

    var input = document.getElementById("myFile").value;
    if (input === "") {
        document.getElementById("errMsg").innerHTML = "please choose file";
        return false;
    }
}

//This method will validate Login Form
function validateLoginForm() {

    var username = document.getElementById("uname").value;
    var password = document.getElementById("password").value;
    if (username === "") {
        document.getElementById("errMsgForUsername").innerHTML = "please Enter Username";
        return false;
    }
    else if(password===""){
    document.getElementById("errMsgForPassword").innerHTML = "please Enter password";
    return false;
    }
    else{
        return true;
    }
}

//This method will validate StoreData Form
function validateStoreDataForm() {

    var fileName = document.getElementById("fileName").value;
    var tableName = document.getElementById("tableName").value;
    if (fileName === "") {
        document.getElementById("errMsgForFileName").innerHTML = "please enter file name";
        return false;
    }
    else if(tableName===""){
    document.getElementById("errMsgForTableName").innerHTML = "please enter table name";
    return false;
    }
    else{
        return true;
    }
}


//This method will responsible for button closing of success and error message 
function closeButton() {
    document.getElementById("message").style.display = "none";
}

//This method will responsible for display of div
function displayMessageDiv() {
    document.getElementById("message").style.display = "block";
}

function databaseConnection() {
    alert("{{message}}");
}


function includeHTML() {
  var z, i, elmnt, file, xhttp;
  /*loop through a collection of all HTML elements:*/
  z = document.getElementsByTagName("*");
  for (i = 0; i < z.length; i++) {
    elmnt = z[i];
    /*search for elements with a certain atrribute:*/
    file = elmnt.getAttribute("w3-include-html");
    if (file) {
      /*make an HTTP request using the attribute value as the file name:*/
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function() {
        if (this.readyState == 4) {
          if (this.status == 200) {elmnt.innerHTML = this.responseText;}
          if (this.status == 404) {elmnt.innerHTML = "Page not found.";}
          /*remove the attribute, and call this function once more:*/
          elmnt.removeAttribute("w3-include-html");
          includeHTML();
        }
      }      
      xhttp.open("GET", file, true);
      xhttp.send();
      /*exit the function:*/
      return;
    }
  }
};
