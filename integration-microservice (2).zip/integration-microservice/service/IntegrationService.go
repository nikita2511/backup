package service

import (
	"fmt"
	"integration-microservice/authentication"
	"integration-microservice/model"
	"integration-microservice/utilities"

	"github.com/micro/go-micro/util/log"
)


//GetJSONIntegrationService Extracts entities from JSON given
func GetJSONIntegrationService(Request model.Request) []byte {
	log.Info("Inside Get Service")
	var BasicToken string
	if Request.Authorization.AuthType == "BasicAuth" {
		Username := Request.Authorization.BasicAuth[0].Value
		Password := Request.Authorization.BasicAuth[1].Value
		BasicToken = authentication.GenerateToken(Username, Password)
		fmt.Println("Basic Token : " + BasicToken)
		return utilities.GetURLData(Request, BasicToken)

	} else if Request.Authorization.AuthType == "OAuth2" {
		AccessToken := Request.Authorization.OAuth2[0].Value
		PrefixHeader := Request.Authorization.OAuth2[1].Value

		return utilities.GetURLData(Request, PrefixHeader+" "+AccessToken)
	}
	return utilities.GetURLData(Request, "")
}

// PostJSONIntegrationService Posts the response of the request
func PostJSONIntegrationService(Request model.Request) []byte {
	log.Info("Inside Post Service")
	log.Info(Request)
	var BasicToken string
	if Request.Authorization.AuthType == "BasicAuth" {
		Username := Request.Authorization.BasicAuth[0].Value
		Password := Request.Authorization.BasicAuth[1].Value
		//Generating token based on username and password
		BasicToken = authentication.GenerateToken(Username, Password)
		fmt.Println("Basic Token : " + BasicToken)
		return utilities.GetURLData(Request, BasicToken)

	} else if Request.Authorization.AuthType == "OAuth2" {
		AccessToken := Request.Authorization.OAuth2[0].Value
		PrefixHeader := Request.Authorization.OAuth2[1].Value
		return utilities.GetURLData(Request, PrefixHeader+" "+AccessToken)
	}
	return utilities.GetURLData(Request, "")
}
