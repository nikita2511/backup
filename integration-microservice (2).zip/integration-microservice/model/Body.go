package model

//These constants represents the available raw languages.
const (
	HTML       string = "html"
	Javascript string = "javascript"
	JSON       string = "json"
	Text       string = "text"
	XML        string = "xml"
)

// Body represents the data usually contained in the request body.
type Body struct {
	ContentType string `json:"Content-Type"`
	Raw         []Raw  `json:"raw"`
}

//Raw struct
type Raw struct {
	Key   string
	Value string
}
