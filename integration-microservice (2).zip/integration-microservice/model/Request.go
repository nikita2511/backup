package model

// Request wrapper contains request's metadata
type Request struct {
	URL           string           `json:"URL" binding:"required"`
	Headers       []RequestHeaders `json:"Headers" binding:"required"`
	QueryParams   []QueryParams    `json:"QueryParams"`
	Authorization Standard         `json:"Authorization"`
	Body          Body             `json:"Body"`
}
