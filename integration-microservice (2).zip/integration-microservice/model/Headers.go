package model

//RequestHeaders are the headers entities
type RequestHeaders struct {
	Key   string `json:"key" binding:"required"`
	Value string `json:"value" binding:"required"`
}


//ResponseHeaders are the headers entities
type ResponseHeaders struct {
	Token         string
	ContentType   string `json:"Content-Type" binding:"required"`
	MethodType    string `json:"Method-Type" binding:"required"`
	Authorization string `json:"Authorization" binding:"required"`
}
