package model

//PostResponse contains response entities
type PostResponse struct {
	Host     string
	URL      string
	Headers  ResponseHeaders
	AuthType string
	Body     string
	Message  string
}


//GetResponse contains response entities
type GetResponse struct {
	URL      string
	Host     string
	Headers  ResponseHeaders
	AuthType string
}
