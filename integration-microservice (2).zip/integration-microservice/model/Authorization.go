package model

// Standard contains authorization's metadata
type Standard struct {
	AuthType  string      `json:"AuthType"`
	BasicAuth []BasicAuth `json:"BasicAuth"`
	OAuth2    []OAuth2    `json:"OAuth2"`
}

// BasicAuth contains BasicAuth's metadata
type BasicAuth struct {
	Key   string `json:"key" binding:"required"`
	Value string `json:"value" binding:"required"`
}

// OAuth2 contains OAuth2's metadata
type OAuth2 struct {
	Key   string `json:"key" binding:"required"`
	Value string `json:"value" binding:"required"`
}
