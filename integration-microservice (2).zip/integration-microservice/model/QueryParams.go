package model

// QueryParams contains key-value pair of the parameters
type QueryParams struct {
	Key   string `json:"key" binding:"required"`
	Value string `json:"value" binding:"required"`
}
