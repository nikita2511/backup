package controller

import (
	"fmt"
	"integration-microservice/model"
	"integration-microservice/service"
	"net/http"
	"github.com/gin-gonic/gin"
	"github.com/micro/go-micro/util/log"
)

// IntegrationGetJSON gets required/requested JSON from the url.
func IntegrationGetJSON(c *gin.Context) {

	var Request model.Request

	if err := c.BindJSON(&Request); err != nil {
		log.Error("Invalid json provided.")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid json provided"})
		return
	} else if Request.Authorization.AuthType == "BasicAuth" && (Request.Authorization.BasicAuth[0].Value == "" ||
		Request.Authorization.BasicAuth[1].Value == "") {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid Authorization Info"})
		return
	} else if Request.Authorization.AuthType == "OAuth2" && (Request.Authorization.OAuth2[0].Value == "" ||
		Request.Authorization.OAuth2[1].Value == "") {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid Authorization Info"})
		return
	} else {
		//fmt.Println(service.GetJSONIntegrationService(Request))
		Response := service.GetJSONIntegrationService(Request)
		c.Data(http.StatusOK, "application/json", Response)
	}
}

//IntegrationPostJSON Posts all response
func IntegrationPostJSON(c *gin.Context) {

	var Request model.Request

	if err := c.BindJSON(&Request); err != nil {
		log.Error("Invalid json provided.")
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid json provided"})
		return
	} else {
		fmt.Println(service.PostJSONIntegrationService(Request))
		Response := service.PostJSONIntegrationService(Request)
		c.Data(http.StatusOK, "application/json", Response)
	}
}

// c.JSON(http.StatusOK, Response)
