package utilities

import (
	"bytes"
	"encoding/json"
	"integration-microservice/model"
	"io/ioutil"
	"net/http"
	"net/url"
	"github.com/micro/go-micro/util/log"
)

var appendedURL string
var contentType string
var methodType string

// GetURLData Calls requested url
func GetURLData(Request model.Request, token string) []byte {
	log.Info("Inside Util")
	return GetAllJSON(Request, AppendedURL(Request.QueryParams, Request.URL), token)
}

// GetAllJSON Data from url
func GetAllJSON(Request model.Request, requrl string, token string) []byte {
	HeadersMetadata(Request.Headers)

	//If method is POST
	if methodType == "POST" {
		data := url.Values{}
		for i := 0; len(Request.Body.Raw) > i; i++ {
			log.Info(Request.Body.Raw[i].Key)
			log.Info(Request.Body.Raw[i].Value)
			data.Add(Request.Body.Raw[i].Key, Request.Body.Raw[i].Value)
		}
		log.Info(data)

		client := &http.Client{}
		reqbody, _ := json.Marshal(data)

		log.Info(bytes.NewBuffer(reqbody))

		req, err := http.NewRequest(methodType, requrl, bytes.NewBuffer(reqbody))
		req.Header.Add("Method-type", methodType)
		req.Header.Add("Content-type", contentType)
		req.Header.Add("Authorization", token)
		resp, err := client.Do(req)
		if err != nil {
			return nil
		}
		defer resp.Body.Close()
		contents, err := ioutil.ReadAll(resp.Body)
		log.Info(string(contents))
		return contents
	}


	//If method is GET
	client := &http.Client{}
	req, err := http.NewRequest(methodType, requrl, nil)
	req.Header.Add("Method-type", methodType)
	req.Header.Add("Content-type", contentType)
	req.Header.Add("Authorization", token)
	resp, err := client.Do(req)

	if err != nil {
		return nil
	}
	defer resp.Body.Close()
	contents, err := ioutil.ReadAll(resp.Body)
	return contents
}

//AppendedURL appends the query parameters to url requested
func AppendedURL(queryparams []model.QueryParams, url string) string {
	paramKey := queryparams[0].Key
	paramValue := queryparams[0].Value

	if paramValue == "" {
		return url
	}
	appendedURL = url + "?" + paramKey + "=" + paramValue
	return appendedURL
}

// HeadersMetadata conatins all the request headers information
func HeadersMetadata(Headers []model.RequestHeaders) {
	for i := 0; len(Headers) > i; i++ {
		if Headers[i].Key == "Content-Type" {
			contentType = Headers[i].Value
		} else if Headers[i].Key == "Method-Type" {
			methodType = Headers[i].Value
		}
	}
}
