CONTENTS OF THIS FILE
---------------------

 * Introduction
 * Requirements
 * Installation
 * Configuration
 * Maintainers

INTRODUCTION
------------

The Integration Microservice enables the user to access any type of local as well 
as third-party API/URL to fetch the required needs. This microservice is a middleware 
which checks the type of request(GET/POST etc) accepts the data in JSON format 
and do all the RESTful API operations. This microservice aims to provide the meta data 
as well as response of the requested APIs/URLs such as HOST, URL, Headers, Body, Message.
Also, this microservice comes with two authorization standards such as BasicAuth and 
OAuth2.0 which can be extended to more authorization standards.

 * To get the response of GET-type of request, hit the below URL 
   and it will show the JSON result:
   https://localhost:8080/integration/getrequest

* To get the response of POST-type of request, hit the below URL 
  and it will show the JSON result:
   https://localhost:8080/integration/postrequest


REQUIREMENTS
------------

This microservice requires a JSON formatted request such as URL, Headers, Authorization Standards,
to get the desired reponse which includes Host, Message, Body, URL etc.

INSTALLATION
------------
 
 * Install as you would normally install Integration Microservice. You
   simply need to run the 'install.exe' file to run the application.

CONFIGURATION
-------------

The microservice can run on any port of the system. If you want, you can 
also mention any specific port, otherwise, the application would implicitly 
select '8080' port(default). Admin also needs to import various libraries which
currently reside in the go.mod and go.sum file.

Also, the admin needs to set the database details inside config.go file according 
to the respected meta-data.

MAINTAINERS
-----------
* Shashank Shakya - shashank.shakya@yash.com
* Himanshu Kapse - himanshu.kapse@yash.com


