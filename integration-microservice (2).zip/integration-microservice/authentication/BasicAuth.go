package authentication

import (
	"log"

	"golang.org/x/crypto/bcrypt"
)

//GenerateToken generate tokens based on username and passwords
func GenerateToken(username, password string) string {
	hash, err := bcrypt.GenerateFromPassword([]byte(username+password), bcrypt.DefaultCost)
	if err != nil {
		log.Fatal(err)
	}

	return string(hash)

}
