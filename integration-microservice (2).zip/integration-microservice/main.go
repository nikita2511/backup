package main

import (
	"integration-microservice/controller"

	"github.com/gin-gonic/gin"
)

// main funcx
func main() {

	router := gin.Default()
	integration := router.Group("/integration")
	integration.POST("/getrequest", controller.IntegrationGetJSON)
	integration.POST("/postrequest", controller.IntegrationPostJSON)
	router.Run()

}
