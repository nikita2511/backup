const express = require('express');
const app = express();
app.use(express.json());
const { body, validationResult } = require('express-validator');

app.post('/user', [
    body('username').isEmail(),
    body('password').isLength({ min: 5 })
], (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() });
    }
    User.create({
        username: req.body.username,
        password: req.body.password
    }).then(user => res.json(user));
});

app.listen(3001)