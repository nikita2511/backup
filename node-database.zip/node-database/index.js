var express = require("express");
const app = express();
var mysql = require("mysql");

//db connection
const dbConnection = mysql.createConnection({
    host :"localhost",
    user:"root",
    password:"root",
    database:"node_demo"
   
})

//connect
dbConnection.connect((err)=>{
    if(!err){
        console.log("connected succesfully");
    }
    else{
        console.log("connection failed"+err);
    }
})


//db connection
app.get("/connectDb",function(req,res){
    let sql = "create database node_demo"
    dbConnection.query(sql,(err,result)=>{
        if(err){
             throw err;
        console.log(result)
        }
        res.send("database created");
    })
})

//table creation
app.get("/createTable",function(req,res){
    var sql = "create table students (id int AUTO_INCREMENT ,name varchar(20),age int(10),city varchar(20),PRIMARY KEY(id))"
    dbConnection.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send("student table has been created");
    })
})

//insertion of student
app.get("/insertStudent1",function(req,res){
let student = {name:"nikita",age:23,city:"indore"};
let sql = "INSERT INTO STUDENTS SET ?";
    dbConnection.query(sql,student,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send("student 1 added");
    })
})

//insertion of student 2
app.get("/insertStudent2",function(req,res){
    let student = {name:"tarun",age:21,city:"nagpur"};
    let sql = "INSERT INTO STUDENTS SET ?";
        dbConnection.query(sql,student,(err,result)=>{
            if(err) throw err;
            console.log(result);
            res.send("student 2 added");
        })
    })
    
    //get all students
    app.get("/getStudents",function(req,res){
        let sql = "SELECT * FROM STUDENTS";
            let query = dbConnection.query(sql,(err,result)=>{
                if(err) throw err;
                console.log(result );
                console.log(query)
                res.send(result);
            })
        })

        //get student by id
        app.get("/getStudent/:id",function(req,res){
            let sql = 'select * from students id = ${req.params.id}';
                let query = dbConnection.query(sql,(err,result)=>{
                    if(err) throw err;
                    console.log(result );
                    console.log(query)
                    res.send(result);
                })
            })
    

app.listen(3001)




