const express = require("express")
const router = express.Router()
const { integrationMethod } = require("./controllers/IntegrationController");
const { validateBody } = require("./utilities/Validation");
router.post("/integrationMicroservice", validateBody, integrationMethod);
module.exports = router