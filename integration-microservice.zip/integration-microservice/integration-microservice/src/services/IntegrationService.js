const axios = require("axios")
const { setBasicAuthConfig, setOAuth2Config, setNoAuthConfig, setPostConfig, setConfigParams } = require("../utilities/ConfigBody")
const QueryParams = require("../models/QueryParams")
const Body = require("../models/Body")
const Url = require("../models/Url")
const MethodType = require("../models/MethodType")
const Headers = require("../models/Headers")


module.exports = {
    integrationGetMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            logger.info('get service method calling');
            const URL = new Url(body)
            const methodType = new MethodType(body)
            const headers = new Headers(body)
            const queryParams = new QueryParams(body)
            console.log(queryParams)
            if (body.QueryParams[0].key == "") {
                axios.get(
                        URL.url, { headers: headers.headerValues }
                    )
                    .then((response) => {
                            return resolve(response)
                        },
                        (error) => {
                            return reject(error)
                        }
                    );
            } else {
                axios.get(
                        URL.url, { params: queryParams.params }, { headers: headers.headerValues }
                    )
                    .then((response) => {
                            return resolve(response)
                        },
                        (error) => {
                            return reject(error)
                        }
                    );
            }
        })
    },

    integrationPostMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            logger.info('post service method calling');
            const URL = new Url(body)
            const headers = new Headers(body)
            const raw = new Body(body)
            axios.post(
                    URL.url, raw.body, { headers: headers.headerValues }
                )
                .then((response) => {
                        return resolve(response)
                    },
                    (error) => {
                        return reject(error)
                    }
                );
        })

    },

    integrationPutMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            logger.info('put service method calling');
            const URL = new Url(body)
            const headers = new Headers(body)
            const raw = new Body(body)
            axios.put(
                URL.url, raw.body, { headers: headers.headerValues }
            ).then((response) => {
                    return resolve(response)
                },
                (error) => {
                    return reject(error)
                }
            );
        })
    },


    integrationDeleteMethodService: async(body) => {
        return new Promise((resolve, reject) => {
            logger.info('delete service method calling');
            const URL = new Url(body)
            const headers = new Headers(body)
            axios.delete(
                URL.url, { headers: headers.headerValues }
            ).then((response) => {
                    return resolve(response)
                },
                (error) => {
                    return reject(error)
                }
            );
        })

    }
}