const { json } = require("express");


//this model will set Query parameters for get api call
function Headers(data) {

    var headers = data.Headers.map(function(header) {
        return header
    });
    let map = new Map()
    for (let index = 0; index < headers.length; index++) {
        map.set(headers[index].key, headers[index].value);
    }
    let headerValues = {};
    map.forEach((value, key) => {
        headerValues[key] = value
    });
    this.headerValues = headerValues


}
Headers.prototype.getHeaders = function() {
    return this.headerValues;
}

module.exports = Headers