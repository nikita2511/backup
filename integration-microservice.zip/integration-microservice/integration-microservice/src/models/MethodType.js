//this is model which will set method type for api call
function MethodType(data) {
    this.methodType = data.MethodType
}
MethodType.prototype.getMethodType = function() {
    return this.methodType;
}
module.exports = MethodType