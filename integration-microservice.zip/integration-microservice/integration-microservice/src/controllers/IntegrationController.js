const { integrationGetMethodService, integrationPostMethodService, integrationPutMethodService, integrationDeleteMethodService } = require("../services/IntegrationService")
const bodyParser = require("body-parser")
var logger = require('../utilities/log');

module.exports = {
    integrationMethod: async(req, res) => {
        try {
            logger.info('controller method calling');
            const body = req.body
            const method = body.MethodType
            if (method == 'GET') {
                const result = await integrationGetMethodService(body)
                res.json({
                    data: result.data
                })
            } else if (method == 'POST') {
                const result = await integrationPostMethodService(body)
                res.json({
                    status: result.status,
                    statusText: result.statusText,
                    data: result.data
                })
            } else if (method == 'PUT') {
                const result = await integrationPutMethodService(body)
                res.json({
                    status: result.status,
                    statusText: result.statusText,
                    data: result.data
                })
            } else if (method == 'DELETE') {
                const result = await integrationDeleteMethodService(body)
                res.json({
                    status: result.status,
                    statusText: result.statusText,
                    data: result.data
                })
            }
        } catch (next) {
            res.json({
                status: next.response.status,
                statusText: next.response.statusText,
                message: next.response.data.error
            })
        }
    },

}