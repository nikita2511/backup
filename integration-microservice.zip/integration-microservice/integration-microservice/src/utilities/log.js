const winston = require('winston');
//log file 
const logger = winston.createLogger({
    transports: [
        new winston.transports.Console()
    ]
});
module.exports = logger;