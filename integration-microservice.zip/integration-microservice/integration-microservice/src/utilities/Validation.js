const { check, validationResult, body } = require("express-validator");
//this method will validate json object
exports.validateBody = [
    check('URL').notEmpty().withMessage("URL cannot be blank"),
    check('MethodType').notEmpty().withMessage("please enter Method Type"),
    (req, res, next) => {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(422).json({ errors: errors.array() });
        } else next();
    }
];