const bodyParser = require("body-parser");
const express = require("express")
const app = express()
const UserRouter = require("./src/router")
require("dotenv").config()

//middlewares
app.use(express.json())
app.use(express.urlencoded({ extended: false }));
app.use("/", UserRouter)

//localhost port listening
app.listen(process.env.APP_PORT, () => {
    console.log("listening to the port ", process.env.APP_PORT)
})