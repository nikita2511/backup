const db = require("../models/index")
const User = db.users


module.exports = {

    createUser: (data) => {
        return new Promise((resolve, reject) => {
            db.sequelize.sync()
            User.findOne({
                where: { userName: data.userName }
            }).then((result) => {
                if (result == null) {
                    User.create(data).then((result) => {
                        return resolve(result)
                    }).catch((err) => {
                        return reject(err)
                    })
                } else {
                    return reject({ message: "userName already exist" })
                }

            }).catch((err) => {
                return reject(err)
            })
        })
    },

    findByUserName: (data) => {
        return new Promise((resolve, reject) => {
            User.findOne({
                where: { userName: data.userName }
            }).then((result) => {
                if (result != null) {
                    if (result.password == data.password) {
                        return resolve(result)
                    } else {
                        return reject({ message: "invalid password" })
                    }
                }
                return reject({ message: "userName doesn't exist please register yourself" })
            }).catch((err) => {
                return reject(err)

            });

        })


    },


    findAllUsers: () => {
        return new Promise((resolve, reject) => {
            User.findAll().then((result) => {
                if (result == null) {
                    return reject({ message: "record not found" })
                }
                return resolve(result)
            }).catch((err) => {
                return reject(err)
            });

        })
    },


    findUserById: (id) => {
        return new Promise((resolve, reject) => {
            User.findOne({
                where: {
                    id: id
                }
            }).then((result) => {
                if (result == null) {
                    return reject({ message: "record not found" })
                }
                return resolve(result)
            }).catch((err) => {
                return reject(err)
            });

        })

    },

    updateUser: (id) => {
        return new Promise((resolve, reject) => {
            User.findOne({
                where: {
                    id: id
                }
            }).then((result) => {
                if (result == null) {
                    return reject({ message: "record not found" })
                }
                return resolve(result)
            }).catch((err) => {
                return reject(err)
            });

        })

    },

    deleteUser: (id) => {
        return new Promise((resolve, reject) => {
            User.destroy({
                where: {
                    id: id
                }
            }).then((result) => {
                if (result == 1) {
                    return resolve({ message: `record whose id is ${id} deleted successfully` })
                }
                return reject({ message: `no record found by id : ${id} ` })
            }).catch((err) => {
                return reject(err)
            });

        })

    },






}