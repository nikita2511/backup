module.exports = (sequelize, Sequelize) => {
    const User = sequelize.define("users", {
        name: {
            type: Sequelize.String
        },
        userName: {
            type: Sequelize.String
        },
        email: {
            type: Sequelize.String
        },
        password: {
            type: Sequelize.String
        },
        email: {
            contact: Sequelize.String
        },
    })
    return User;

}