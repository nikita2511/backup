const express = require("express")
const { register, login, getAllUsers, getUserById, deleteUser } = require("./controllers/userController")
    // const { validateRegistration, validateLogin } = require("./utility/validation")

const router = express.Router()
router.post("/register", register)
router.post("/login", login)
router.patch("/getAllUsers", getAllUsers)
router.get("/:id", getUserById)
router.delete("/:id", deleteUser)



module.exports = router