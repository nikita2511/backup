var fs = require("fs");
var data = "this is data for file output text file";

var writingstream = fs.createWriteStream("output.txt");

writingstream.write(data, "utf8");
writingstream.end();
writingstream.on("finish", function () {
  console.log("writing task completed");
});

writingstream.on("error", function (err) {
  console.log(err.stack);
});

console.log("program ended");
