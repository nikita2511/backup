var fs = require("fs");
console.log("going to close existing file");
fs.unlink("input.txt", function (err) {
  if (err) {
    return console.error(err);
  }
  console.log("file has been deleted successfully");
});
