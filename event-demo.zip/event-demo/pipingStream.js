var fs = require("fs");
var readingStream = fs.createReadStream("input.txt");
var writingStream = fs.createWriteStream("output.txt");
readingStream.pipe(writingStream);
console.log("program ended");
