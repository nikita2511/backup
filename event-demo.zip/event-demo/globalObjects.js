const { setInterval } = require("timers");

//filename 1
console.log(__filename);
//dirname 2
console.log(__dirname);

//setTimeout 3
function printHello() {
  console.log("this is hello function will call after 2 seconds");
}
var t = setTimeout(printHello, 2000);
console.log(t);

//clearTimeout : clear timer set in setTimeout function
clearTimeout(t);

//setInterval(cb,ms)(repeatation calling of function after every 2 sec)
// setInterval(printHello, 2000);
console.log(process);
