var fs = require("fs");
var buf = Buffer.alloc(1024);

//reading file by read() method
fs.open("input.txt", "r+", function (err, fd) {
  if (err) {
    return console.error(err);
  }

  console.log("file has been opened successfully");
  console.log("going to read file");

  fs.read(fd, buf, 0, buf.length, 0, function (err, bytes) {
    if (err) {
      console.log(err);
    }
    console.log(bytes + "bytes read");
    if (bytes > 0) {
      console.log(buf.slice(0, bytes).toString());
      console.log(buf.length);
    }
    //closing file
    fs.close(fd, function (err) {
      if (err) {
        console.log(err);
      }
      console.log("file closed successfully");
      console.log(fd);
    });
  });
});
