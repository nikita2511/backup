var fs = require("fs");
fs.writeFile("output.txt", "this is data for output file", function (
  err,
  data
) {
  if (err) console.log(err);
});

fs.readFile("input.txt", function (err, data) {
  if (err) console.log(err);
  console.log(data.toString());
});
