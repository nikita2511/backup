var fs = require("fs");
console.log("file is going to open");
fs.open("input.txt", "r+", function (err, data) {
  if (err) {
    return console.log("error" + err + "data" + data);
  }
  console.log("file open sucessfully" + data);
});

// var fs = require("fs");
// console.log("file started");
// fs.stat("input.txt", function (err, stats) {
//   if (err) {
//     console.log(err);
//   }
//   console.log(stats);
//   console.log("file got into ");
//   console.log(stats.isFile());
//   console.log(stats.isDirectory());
//   console.log(stats.isBlockDevice());
//   console.log(stats.isSymbolicLink());
//   console.log(stats.isFIFO());
//   console.log(stats.isSocket());
// });
