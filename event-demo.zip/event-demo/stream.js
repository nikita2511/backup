var fs = require("fs");
var data = "";
var readingStream = fs.createReadStream("input.txt");
readingStream.setEncoding("utf8");
readingStream.on("data", function (chunk) {
  data += chunk;
});

readingStream.on("end", function () {
  console.log(data);
});

readingStream.on("error", function (err) {
  console.log(err.stack);
});

console.log("program ended");
