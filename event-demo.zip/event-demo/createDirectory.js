var fs = require("fs");
// console.log("going to create directory /temp/test");
// fs.mkdir("./temp/test.js", function (err) {
//   if (err) {
//     return console.error(err);
//   }
//   console.log("directory has been created successfully");
// });

// read directory

fs.readdir("./temp/", function (err, files) {
  if (err) {
    return console.error(err);
  }
  files.forEach(function (file) {
    console.log(file);
  });
});
