//loding event
var events = require("events");
//eventEmitter to emit event
var eventEmitter = new events.EventEmitter();

//event handler
var connectionHandler = function connected() {
  console.log("connection successfull");
  eventEmitter.emit("data-recieved");
};

//binding of event name and event handler
eventEmitter.on("connection", connectionHandler);


eventEmitter.on("data-recieved", function () {
  console.log("data-recived");
});

//event trigger
eventEmitter.emit("connection");
console.log("program end");
