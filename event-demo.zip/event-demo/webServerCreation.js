var http = require("http");
var url = require("url");
var fs = require("fs");

http
  .createServer(function (request, response) {
    var pathname = url.parse(request.url).pathname;
    console.log("pathName :" + pathname + "recieved");

    fs.readFile(pathname.substr(1), function (err, data) {
      if (err) {
        console.log(err);
        response.writeHead(404, { Content_Type: "text/html" });
      } else {
        response.writeHead(200, { Content_Type: "text/html" });
        response.write(data.toString());
      }
      response.end();
    });
  })
  .listen(3001);

console.log("server running on port 3001");
