var events = require("events");
var eventEmitter = new events.EventEmitter();

var listner1 = function listner1() {
  console.log("listner 1 has been called");
};

var listner2 = function listner2() {
  console.log("listner 2 has been called");
};

eventEmitter.addListener("connection", listner1);
eventEmitter.on("connection", listner2);

var eventListener = events.EventEmitter.listenerCount(
  eventEmitter,
  "connection"
);
console.log(eventListener + "listeners listening to the connection event");

eventEmitter.emit("connection");
eventEmitter.removeListener("connection", listner1);
console.log("listner1 will not listen now");
eventEmitter.emit("connection");
var eventListener = events.EventEmitter.listenerCount(
  eventEmitter,
  "connection"
);

console.log(eventListener + "listeners listening to the connection event");
