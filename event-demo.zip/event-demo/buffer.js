Buffer.alloc(5);
for (var i = 0; i <= 5; i++) {
  console.log(i);
}


len = Buffer.from("this is simply learning of node js", "ascii");
// len = buffer.write("node learning");
console.log(len.toJSON(len));

var buf1 = Buffer.from("this is first buffer");
var buf2 = Buffer.from("this is second buffer");
var buf3 = Buffer.from("this is third buffer");

//concatination of buffer
var buffer = Buffer.concat([buf1, buf2, buf3]);
console.log(buffer.toString());

//comaprison of two buffers
var result = buf2.compare(buf1);
console.log(result);
console.log(buf2 + "comes after" + buf1);

// result =-1; if buf1<buf2
// result=1; if buf1>buf2
// result=0; if buf1=buf2

//copy -----------
// buf.copy(targetBuffer[, targetStart][, sourceStart][, sourceEnd])

// buf2.copy(buf4);
// console.log(buf4);

//slice
var bufSlice = buf1.slice(4, 15);
console.log(bufSlice.toString());
console.log(bufSlice.length);

//check for correct encoding argument
console.log(Buffer.isEncoding("uft8"));

//check for buffer is object
console.log(Buffer.isBuffer(buf1));
console.log(Buffer.byteLength("this is string"));
console.log(Buffer.compare(buf1, buf2));
